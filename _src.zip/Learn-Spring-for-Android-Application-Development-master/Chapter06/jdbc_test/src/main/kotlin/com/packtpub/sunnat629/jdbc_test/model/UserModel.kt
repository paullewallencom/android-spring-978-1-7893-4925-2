package com.packtpub.sunnat629.jdbc_test

data class UserModel(val id: Int,
                     val name: String,
                     val email: String,
                     val contact_number: String)