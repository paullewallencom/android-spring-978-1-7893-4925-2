package com.packtpub.sunnat629.jdbc_test

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class JdbcTestApplication

fun main(args: Array<String>) {
    runApplication<JdbcTestApplication>(*args)
}
