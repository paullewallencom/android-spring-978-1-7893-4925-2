create table users (id int not null auto_increment, name varchar(255), email varchar(255), contact_number varchar(255)
, primary key (id)) engine=MyISAM;
INSERT INTO users ( name, email, contact_number) values ('Sunnat', 'sunnat629@gmail.com', '1234567890');
INSERT INTO users ( name, email, contact_number) values ('Chaity', 'chaity123@gmail.com', '9876543210');
INSERT INTO users ( name, email, contact_number) values ('Faysal', 'faysal123@gmail.com', '1004500800');
INSERT INTO users ( name, email, contact_number) values ('Hasib', 'hasib123@gmail.com', '1234500800');
INSERT INTO users ( name, email, contact_number) values ('Kiron', 'kiron123@gmail.com', '02158500800');
INSERT INTO users ( name, email, contact_number) values ('Mirza', 'mirza123@gmail.com', '544567800');
INSERT INTO users ( name, email, contact_number) values ('Zibon', 'zibon123@gmail.com', '865450800');
