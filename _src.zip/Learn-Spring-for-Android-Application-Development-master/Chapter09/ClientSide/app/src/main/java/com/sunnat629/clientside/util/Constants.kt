package com.sunnat629.clientside.util

object Constants {
    const val API_BASE_PATH = "http://10.0.2.2:8080"
    const val TIME_FORMAT = "EEE, d MMM yyyy hh:mm aaa"
}