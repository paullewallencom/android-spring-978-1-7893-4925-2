package autowiredAnnotation

class UserDetails{
    init {
        println("This class has all the details of the user")
    }

    fun getDetails(){
        println("Name: Naruto Uzumaki")
        println("Village: Konohagakure")
    }
}