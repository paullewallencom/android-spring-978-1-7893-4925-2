package mvckotlin

import org.springframework.boot.autoconfigure.SpringBootApplication
import com.sun.tools.javac.tree.TreeInfo.args
import org.springframework.boot.SpringApplication


@SpringBootApplication
open class MVCKotlinApp {
    fun main(args: Array<String>) {
        SpringApplication.run(MVCKotlinApp::class.java, *args)
    }
}