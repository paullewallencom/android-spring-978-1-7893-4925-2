package com.pucktpub.sunnat629.springbootkotlin.springbootkotlin

import org.junit.Test
import org.junit.runner.RunWith
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.junit4.SpringRunner

@RunWith(SpringRunner::class)
@SpringBootTest
class SpringbootkotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
