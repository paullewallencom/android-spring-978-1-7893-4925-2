package dependenciesInjectBean

class GreetingDetailsDIBean{
    init {
        println("This class has all the details of the user")
    }

    fun getGreetingDetails(){
        println("Welcome, Naruto Uzumaki!!")
    }
}