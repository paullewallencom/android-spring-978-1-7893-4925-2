package importAnnotation

class Foo{
    init {
        println("This is class Foo")
    }
}
class Boo{
    init {
        println("This is class Boo")
    }
}
