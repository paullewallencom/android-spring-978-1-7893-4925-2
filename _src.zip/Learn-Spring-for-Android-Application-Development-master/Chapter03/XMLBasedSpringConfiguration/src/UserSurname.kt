package ktPackage

class UserSurname {
    init {
        println("This is init of UserSurname")
    }

    fun getSurname(){
        println("This is the surname of user")
    }
}