package com.packt.learn_spring_for_android_application_development.chapter2

/**
 * Created by ihor_kucherenko on 9/17/18.
 * https://github.com/KucherenkoIhor
 */


var number = 1
val string = "number is $number"


val name = "Igor"
val lengthOfName = "length is ${name.length} and number is $number"