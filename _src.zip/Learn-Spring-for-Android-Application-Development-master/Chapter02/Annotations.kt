package com.packt.learn_spring_for_android_application_development.chapter2

/**
 * Created by ihor_kucherenko on 9/18/18.
 * https://github.com/KucherenkoIhor
 */


class Example1 {
    companion object {
        @JvmStatic
        fun companionClassMember() {}
    }
}