package springforandroid.pactpub.sunnat629.basicauthinkotlin.model


class UserModel (val name: String?,
                 val contact_number: String?,
                 val id: String?,
                 val email: String? )