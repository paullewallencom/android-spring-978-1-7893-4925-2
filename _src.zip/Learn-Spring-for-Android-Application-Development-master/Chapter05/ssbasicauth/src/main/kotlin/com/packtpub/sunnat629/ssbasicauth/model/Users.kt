package com.packtpub.sunnat629.ssbasicauth.model

class Users(val id: String?,
            val name: String?,
            val email: String?,
            val contactNumber: String?)