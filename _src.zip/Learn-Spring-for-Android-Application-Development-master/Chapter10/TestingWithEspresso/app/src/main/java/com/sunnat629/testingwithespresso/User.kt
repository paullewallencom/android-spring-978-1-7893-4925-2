package com.sunnat629.testingwithespresso

data class User(var userID: Int,
                var username: String)