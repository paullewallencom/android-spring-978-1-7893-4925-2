package springforandroid.pactpub.sunnat629.resttemptest

