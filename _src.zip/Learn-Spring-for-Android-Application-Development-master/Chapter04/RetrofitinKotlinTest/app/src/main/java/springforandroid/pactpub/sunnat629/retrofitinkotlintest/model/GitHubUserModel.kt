package springforandroid.pactpub.sunnat629.retrofitinkotlintest.model


class GitHubUserModel {
    val name: String? = null
}
